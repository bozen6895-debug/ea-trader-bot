
AutoLoopGoldEA - README
-----------------------

What this package contains:
- AutoLoopGoldEA.mq5 : Expert Advisor source code for MetaTrader 5.
  Behavior:
   * Opens a position (BUY/SELL/Alternate/Random as configured) on the chart symbol (e.g. XAUUSD).
   * When the open positions' combined profit (for this EA's magic number) reaches the configured USD target (InpProfitTargetUSD),
     the EA closes those positions, counts 1 done cycle, waits InpWaitSecondsBetween seconds, then opens next position.
   * Repeats InpRepeatCount times and then stops automatically.
   * Provides START / STOP buttons on the chart for manual control.
   * Has basic safety checks: max daily loss (InpMaxDailyLossUSD) and minimum balance (InpMinBalanceUSD).

Important safety notes (read before running):
- No EA can guarantee profit. Markets are risky. Test on DEMO first for at least 2-4 weeks.
- Use small lot sizes until you are comfortable with the behavior.
- Brokers have different symbol names, spreads and minimums. Verify symbol (XAUUSD vs XAUUSD.r) and lot steps.
- Keep "Allow automated trading" enabled and Global AutoTrading on in MT5 terminal.

How to install and run (step-by-step):
1) Install MetaTrader 5 desktop and login to your demo account.
2) Open MetaEditor (MT5 -> Tools -> MetaQuotes Language Editor).
3) File -> New -> Expert Advisor or simply create a new .mq5 file.
4) Paste the content of AutoLoopGoldEA.mq5 and Save as AutoLoopGoldEA.mq5.
5) Click Compile. If there are compile errors, copy error text and share with me so I can fix.
6) In MT5 terminal, open a XAUUSD chart (M1 or any timeframe).
7) In Navigator -> Expert Advisors, drag AutoLoopGoldEA to the chart.
8) In the EA properties dialog enable "Allow live trading" and adjust the inputs:
   - InpLot = 0.01
   - InpProfitTargetUSD = 5.0
   - InpRepeatCount = 5
   - InpWaitSecondsBetween = 2
   - InpSideMode = 2  (alternate)
   - InpMaxDailyLossUSD = 50.0
   - InpMinBalanceUSD = 10.0
9) Click OK. Use the START button that appears on the chart to begin.
10) Monitor the Experts and Journal tabs for logs, and check Trades/Account History.

If you want me to help further, I can provide:
- A troubleshooting checklist for common compile/runtime errors.
- A short VPS setup script and instructions for keeping EA online 24/7.
- Optional: Telegram notifications when done cycles complete or when EA stops.
- Guidance on converting USD profit target to pips or percentage if you prefer that.

I cannot access your MT5 account or run the EA on your behalf. I can, however, provide exact instructions, fix code issues, and prepare additional helper scripts. If you want me to add features (telegrams, logging, adaptive TP/SL) tell me which and I will generate the updated code.

--- End README
